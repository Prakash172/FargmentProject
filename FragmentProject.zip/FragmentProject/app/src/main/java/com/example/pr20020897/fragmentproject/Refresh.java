package com.example.pr20020897.fragmentproject;

public interface Refresh {
    void refresh();
}
