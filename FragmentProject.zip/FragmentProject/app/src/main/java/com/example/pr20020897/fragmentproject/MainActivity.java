package com.example.pr20020897.fragmentproject;

import android.app.Fragment;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int id;
    Intent intent;
    Fragment playerList, playerDetails;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playerDetails = getFragmentManager().findFragmentById(R.id.detailsFragment);
        playerList = getFragmentManager().findFragmentById(R.id.playerFragment);
        intent = getIntent();

    }

//    @Override
//    public void refresh() {
//
//        id = intent.getIntExtra("id",99);
//        Toast.makeText(this,"position : "+id,Toast.LENGTH_SHORT).show();
//    }
}
