package com.example.pr20020897.fragmentproject;


import android.net.sip.SipSession;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailsFragment extends Fragment {

    TextView name, bio, dob,spouse,height;
    ImageView pic;


    public DetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);
        name = view.findViewById(R.id.name);
        bio = view.findViewById(R.id.bio);
        dob = view.findViewById(R.id.dob);
        spouse = view.findViewById(R.id.spouse);
        height = view.findViewById(R.id.height);
        pic = view.findViewById(R.id.image);

        Details details = new Details();
        Bundle bundle = getArguments();
        if(bundle != null){
            int id = bundle.getInt("pos",0);
            name.setText(details.name[id]);
            pic.setBackgroundResource(details.imageId[id]);
            bio.setText(details.bio[id]);
            dob.setText(details.dob[id]);
            spouse.setText(details.Spouse[id]);
            height.setText(details.height[id]);
        }



        return  view;
    }

}
