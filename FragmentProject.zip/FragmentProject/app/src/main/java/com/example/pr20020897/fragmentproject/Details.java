package com.example.pr20020897.fragmentproject;

public class Details {
    String [] name = {"Sachin","M.S. Dhoni","Yuvraj Singh","Suresh Raina","Virat Kohli", "Gautam Gambhir","Ravindra Jadeja"};
    String [] age = {"45 years","37 years","36 years","31 years","29 years","36 years","29 years"};
    String [] dob = {"24 April 1973","7 July 1981 ","12 December 1981","27 November 1986 ","5 November 1988","14 October 1981"," 6 December 1988"};
    String [] bio = {"Sachin Ramesh Tendulkar is a former Indian international cricketer and a former captain of the Indian national team, regarded as one of the greatest batsmen of all time. He is the highest run scorer of all time in International cricket.",
                     "Mahendra Singh Dhoni is an Indian international cricketer who captained the Indian national team in limited-overs formats from 2007 to 2016 and in Test cricket from 2008 to 2014.",
                     "Yuvraj Singh is an Indian international cricketer, who plays all forms of the game. An all-rounder who bats left-handed in the middle order and bowls slow left-arm orthodox, Yuvraj is the son of former ",
                     "Suresh Kumar Raina is an Indian international cricketer. An aggressive left-handed middle-order batsman and an occasional off-spin bowler, he is also regarded as one of the best fielders in world cricket.",
                     "Virat Kohli is an Indian international cricketer who currently captains the India national team. An elegant right-handed batsman, Kohli is regarded as one of the best batsmen in the world.",
                     "Gautam Gambhir is an Indian cricketer, who played all formats of the game. He is a left-handed opening batsman who plays domestic cricket for Delhi, and captained Kolkata Knight Riders in the Indian Premier League.",
                    "Ravindrasinh Anirudhsinh Jadeja, commonly known as Ravindra Jadeja, is an Indian international cricketer. He is an all-rounder, who plays as a left-handed middle-order batsman and slow left-arm orthodox bowler."
    };

    String [] height = {"1.65 m","1.75 m","1.88 m","1.75 m","1.75 m","1.68 m","1.73 m"};
    String [] Spouse ={" Anjali Tendulkar"," Sakshi Dhoni","Hazel Keech","Priyanka Chaudhary","Anushka sharma","Natasha Jain", "Riva Solanki "};
    int [] imageId = {R.drawable.sachin,R.drawable.dhoni,R.drawable.yuvi,R.drawable.raina,R.drawable.kohli,R.drawable.gautam,R.drawable.jadeja};

}
